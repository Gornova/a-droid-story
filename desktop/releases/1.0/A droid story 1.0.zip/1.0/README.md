A droid story
v1.0
A game made in one week by Random tower of games - 2017
http://randomtower.blogspot.it


1. Introduction

You control a small droid in a series of levels in order to find the exit.


2. Controls

Arrows or WASD to move the droid


3. Thanks to

Libgdx
Hiero
For the music: 	http://www.orangefreesounds.com/ambient-piano-loop-105-bpm/


4. Problems ?

In order to run a droid story, you need Java 8 and double click on the jar to run it.
Or run using command line:

java -jar Adroidstory.jar