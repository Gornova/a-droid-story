# A droid story 

v1.3

A game made in one week by Random tower of games - 2017

http://randomtower.blogspot.it


## Introduction

You control a small droid in a series of levels in order to find the exit.


## Controls

Arrows or WASD to move the droid


## Thanks to

* Libgdx
* Hiero
* For the music: 	http://www.orangefreesounds.com/ambient-piano-loop-105-bpm/
* libgdx transitions: https://github.com/digital-thinking/libgdx-transitions


## Problems ?

In order to run a droid story, you need Java 8 and double click on the jar to run it.
Or run using command line:

java -jar Adroidstory.jar


## Changes

### 1.3
- fixed music issue converting wav to ogg

### 1.2
- added transitions between game states
- added level selection

### 1.1
- expand text on game over screen
- 5 new levels !